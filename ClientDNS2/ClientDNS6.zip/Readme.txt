ClientDNS is a utility program designed and intended to give you full access to the DNS packets 
returned from the requested server. DNS packets are very compact and highly cryptic, and because 
of that, command line utilities like "NSLookUP" will display incomplete interpretted results. 
ClientDNS returns all the results on separate tabs.

ClientDNS has been tested to be UAC compatible.

Internet standards require DNS servers to accept both UDP and TCP requests. TCP is very seldom 
used however, and some servers do not accept them due to firewall restrictions on port 53. 
ClientDNS does not support TCP.

ClientDNS finds and uses your default DNS servers to get the IP addresses of the named servers. 
Consequently, it cannot be used to troubleshoot your own DNS service unless you manually enter 
the IP address of the server. This version supports IPv6, but it has experienced limited testing 
in this mode because of the inavailability of IPv6 transport. Feedback would be welcome.